//
//  descripcionView.swift
//  Covid-lineage
//
//  Created by Alumno on 1/21/22.
//  Copyright © 2022 Alumno. All rights reserved.
//

import Foundation
