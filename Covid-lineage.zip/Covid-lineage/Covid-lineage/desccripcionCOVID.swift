//
//  desccripcionCOVID.swift
//  Covid-lineage
//
//  Created by Alumno on 1/21/22.
//  Copyright © 2022 Alumno. All rights reserved.
//

import Foundation
import UIKit


class DescripcionCovid : UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 150
    }
    
    var covids : [Covid] = []
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return covids.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let celda = tableView.dequeueReusableCell(withIdentifier: "CeldaDescripcion") as! CeldaCOVID
        
        
        celda.lblNombre.text = covids[indexPath.row].nombre
        celda.lblLineage.text = covids[indexPath.row].date
        celda.lblAssigned.text = covids [indexPath.row].assigned
        celda.lblDesigned.text = covids [indexPath.row].designed
        celda.lblDate.text = covids [indexPath.row].date
        
        
        return celda
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        
        
    }
    
    
}
