//
//  covid_class.swift
//  Covid-lineage
//
//  Created by Alumno on 1/21/22.
//  Copyright © 2022 Alumno. All rights reserved.
//

import Foundation

class Covid {
    var nombre = ""
    var date = ""
    var designed = ""
    var assigned = ""
    var lineage = ""
    
    
    
    init(nombre: String, date: String, designed: String, assigned: String, lineage: String) {
        self.nombre = nombre
        self.date = date
        self.designed = designed
        self.assigned = assigned
        self.lineage = lineage
        
    }
    
}
