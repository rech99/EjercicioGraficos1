//
//  descView.swift
//  Covid-lineage
//
//  Created by Alumno on 1/21/22.
//  Copyright © 2022 Alumno. All rights reserved.
//

import Foundation
import UIKit

class CoviddDetalles: UIViewController {
    
    /**
    
    @IBOutlet weak var lblNombre: UILabel!
    @IBOutlet weak var lblLineage: UILabel!
    @IBOutlet weak var lblAsigned: UILabel!
    @IBOutlet weak var lblDesigned: UILabel!
    @IBOutlet weak var lblDate: UILabel!
 
 **/
    @IBOutlet weak var lblDescripcion: UILabel!
    
    var variantita : Covid?
    
    
    /**
    override func viewDidLoad() {
        super.viewDidLoad()
        
        lblDescripcion.text = variantita!.descripcion
        
        
        
        
    }
    
**/
    
    
}


