//
//  descCOVID.swift
//  Covid-lineage
//
//  Created by Alumno on 1/21/22.
//  Copyright © 2022 Alumno. All rights reserved.
//

import Foundation


class DescCovid {
    var nombre = ""
    var date = ""
    var designed = ""
    var assigned = ""
    var lineage = ""
    var descripcion = ""
    
    
    
    init(nombre: String, date: String, designed: String, assigned: String, lineage: String, descripcion: String) {
        self.nombre = nombre
        self.date = date
        self.designed = designed
        self.assigned = assigned
        self.lineage = lineage
        self.descripcion = descripcion
        
    }

}
